---
title: "R Notebook"
author: "Jennifer"
output: html_notebook
---
## Load Data


```R
airbnb_data <- read.csv("AirBnB.csv", header = T, na.strings = "") # set "" to NA
airbnb_data
```


<table class="dataframe">
<caption>A data.frame: 7833 × 41</caption>
<thead>
	<tr><th scope=col>host_id</th><th scope=col>host_name</th><th scope=col>host_since_year</th><th scope=col>host_since_anniversary</th><th scope=col>Customer.Since</th><th scope=col>Age.in.years</th><th scope=col>id</th><th scope=col>neighbourhood_cleansed</th><th scope=col>city</th><th scope=col>city_translated</th><th scope=col>⋯</th><th scope=col>host_response_time</th><th scope=col>host_response_rate</th><th scope=col>number_of_reviews</th><th scope=col>review_scores_rating</th><th scope=col>review_scores_accuracy</th><th scope=col>review_scores_cleanliness</th><th scope=col>review_scores_checkin</th><th scope=col>review_scores_communication</th><th scope=col>review_scores_location</th><th scope=col>review_scores_value</th></tr>
	<tr><th scope=col>&lt;int&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>⋯</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><td> 1662</td><td>Chloe             </td><td>2008</td><td>8/11 </td><td>8/11/08 </td><td>8.93</td><td> 304958</td><td>Westerpark                            </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within a day      </td><td>0.8 </td><td> 11</td><td> 98</td><td>10</td><td>10</td><td> 9</td><td>10</td><td>10</td><td>10</td></tr>
	<tr><td> 3159</td><td>Daniel            </td><td>2008</td><td>9/24 </td><td>9/24/08 </td><td>8.80</td><td>   2818</td><td>Oostelijk Havengebied - Indische Buurt</td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within an hour    </td><td>1   </td><td>108</td><td> 97</td><td>10</td><td>10</td><td>10</td><td>10</td><td> 9</td><td>10</td></tr>
	<tr><td> 3718</td><td>Britta            </td><td>2008</td><td>10/19</td><td>10/19/08</td><td>8.74</td><td> 103026</td><td>De Baarsjes - Oud-West                </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within a few hours</td><td>1   </td><td> 15</td><td> 92</td><td> 9</td><td> 9</td><td>10</td><td>10</td><td> 9</td><td> 9</td></tr>
	<tr><td> 4716</td><td>Stefan            </td><td>2008</td><td>11/30</td><td>11/30/08</td><td>8.62</td><td> 550017</td><td>Centrum-Oost                          </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within a day      </td><td>1   </td><td> 20</td><td> 97</td><td>10</td><td>10</td><td>10</td><td>10</td><td>10</td><td>10</td></tr>
	<tr><td> 5271</td><td>Tyler             </td><td>2008</td><td>12/17</td><td>12/17/08</td><td>8.57</td><td>4728389</td><td>Centrum-West                          </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within a day      </td><td>0.89</td><td>  1</td><td>100</td><td> 8</td><td>10</td><td> 8</td><td>10</td><td>10</td><td> 6</td></tr>
	<tr><td> 5271</td><td>Tyler             </td><td>2008</td><td>12/17</td><td>12/17/08</td><td>8.57</td><td>5500954</td><td>Centrum-West                          </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within a day      </td><td>0.9 </td><td>  0</td><td> NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td> 5271</td><td>Tyler             </td><td>2008</td><td>12/17</td><td>12/17/08</td><td>8.57</td><td>5181918</td><td>Centrum-West                          </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within a day      </td><td>0.89</td><td>  4</td><td> 95</td><td> 9</td><td> 9</td><td> 9</td><td>10</td><td>10</td><td> 9</td></tr>
	<tr><td> 5988</td><td>Ramona            </td><td>2009</td><td>1/4  </td><td>1/4/09  </td><td>8.53</td><td>2774924</td><td>Zuid                                  </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within an hour    </td><td>1   </td><td> 33</td><td> 95</td><td> 9</td><td>10</td><td>10</td><td>10</td><td>10</td><td> 9</td></tr>
	<tr><td> 9616</td><td>Laura             </td><td>2009</td><td>3/9  </td><td>3/9/09  </td><td>8.35</td><td>  23651</td><td>De Pijp - Rivierenbuurt               </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within a day      </td><td>1   </td><td> 36</td><td> 96</td><td> 9</td><td>10</td><td>10</td><td>10</td><td> 9</td><td> 9</td></tr>
	<tr><td>14589</td><td>Rutger            </td><td>2009</td><td>4/23 </td><td>4/23/09 </td><td>8.23</td><td> 738245</td><td>Centrum-West                          </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>N/A               </td><td>N/A </td><td>  8</td><td> 93</td><td>10</td><td> 9</td><td> 9</td><td> 9</td><td>10</td><td> 9</td></tr>
	<tr><td>15618</td><td>Shelly            </td><td>2009</td><td>5/2  </td><td>5/2/09  </td><td>8.20</td><td>  51969</td><td>De Pijp - Rivierenbuurt               </td><td>De Pijp  </td><td>De Pijp  </td><td>⋯</td><td>within a few hours</td><td>1   </td><td>  3</td><td> 95</td><td>10</td><td> 9</td><td>10</td><td>10</td><td>10</td><td>10</td></tr>
	<tr><td>21669</td><td>Mark              </td><td>2009</td><td>6/15 </td><td>6/15/09 </td><td>8.08</td><td>   8061</td><td>De Baarsjes - Oud-West                </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within a day      </td><td>0.75</td><td>  2</td><td>100</td><td>10</td><td>10</td><td>10</td><td>10</td><td>10</td><td>10</td></tr>
	<tr><td>26919</td><td>Hugo              </td><td>2009</td><td>7/22 </td><td>7/22/09 </td><td>7.98</td><td>  98558</td><td>Centrum-Oost                          </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within an hour    </td><td>1   </td><td> 19</td><td> 99</td><td>10</td><td>10</td><td>10</td><td>10</td><td>10</td><td> 9</td></tr>
	<tr><td>32366</td><td><span style=white-space:pre-wrap>Sabine &amp; Sander   </span></td><td>2009</td><td>8/18 </td><td>8/18/09 </td><td>7.91</td><td><span style=white-space:pre-wrap>   9693</span></td><td><span style=white-space:pre-wrap>Centrum-West                          </span></td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td><span style=white-space:pre-wrap>within a day      </span></td><td>0.9 </td><td> 34</td><td> 99</td><td>10</td><td>10</td><td>10</td><td>10</td><td>10</td><td> 9</td></tr>
	<tr><td>36701</td><td>Leonie            </td><td>2009</td><td>9/7  </td><td>9/7/09  </td><td>7.85</td><td>2323819</td><td>Bos en Lommer                         </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within a few hours</td><td>1   </td><td> 13</td><td>100</td><td>10</td><td>10</td><td>10</td><td>10</td><td> 9</td><td>10</td></tr>
	<tr><td>42212</td><td>Miguel            </td><td>2009</td><td>9/29 </td><td>9/29/09 </td><td>7.79</td><td> 280105</td><td>Centrum-West                          </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within an hour    </td><td>0.96</td><td> 18</td><td> 99</td><td>10</td><td>10</td><td>10</td><td>10</td><td>10</td><td> 9</td></tr>
	<tr><td>42212</td><td>Miguel            </td><td>2009</td><td>9/29 </td><td>9/29/09 </td><td>7.79</td><td>3527892</td><td>Centrum-West                          </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within an hour    </td><td>0.96</td><td>  2</td><td>100</td><td>10</td><td>10</td><td>10</td><td>10</td><td>10</td><td>10</td></tr>
	<tr><td>42725</td><td>Marco             </td><td>2009</td><td>10/1 </td><td>10/1/09 </td><td>7.79</td><td> 933385</td><td>De Baarsjes - Oud-West                </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within a few hours</td><td>1   </td><td> 19</td><td> 98</td><td>10</td><td>10</td><td>10</td><td>10</td><td>10</td><td>10</td></tr>
	<tr><td>46431</td><td>Jennifer &amp; Michiel</td><td>2009</td><td>10/17</td><td>10/17/09</td><td>7.74</td><td>1182306</td><td><span style=white-space:pre-wrap>Zuid                                  </span></td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within a few hours</td><td><span style=white-space:pre-wrap>1   </span></td><td> 58</td><td> 95</td><td> 9</td><td>10</td><td> 9</td><td> 9</td><td> 9</td><td> 9</td></tr>
	<tr><td>47517</td><td>Geert             </td><td>2009</td><td>10/21</td><td>10/21/09</td><td>7.73</td><td>3047061</td><td>Watergraafsmeer                       </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>N/A               </td><td>N/A </td><td>  0</td><td> NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>50517</td><td>Sanne             </td><td>2009</td><td>11/1 </td><td>11/1/09 </td><td>7.70</td><td>4003922</td><td>Centrum-Oost                          </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>a few days or more</td><td>0.4 </td><td>  0</td><td> NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>56142</td><td>Joan              </td><td>2009</td><td>11/20</td><td>11/20/09</td><td>7.65</td><td>1003865</td><td>De Baarsjes - Oud-West                </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within a few hours</td><td>1   </td><td>  0</td><td> NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>56142</td><td>Joan              </td><td>2009</td><td>11/20</td><td>11/20/09</td><td>7.65</td><td>  25428</td><td>Centrum-West                          </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within a few hours</td><td>1   </td><td>  0</td><td> NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>59059</td><td>Marius            </td><td>2009</td><td>12/1 </td><td>12/1/09 </td><td>7.62</td><td>  75583</td><td>Slotervaart                           </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within an hour    </td><td>1   </td><td>107</td><td> 99</td><td>10</td><td>10</td><td>10</td><td>10</td><td> 9</td><td>10</td></tr>
	<tr><td>59297</td><td>Jan               </td><td>2009</td><td>12/2 </td><td>12/2/09 </td><td>7.62</td><td>  15061</td><td>Westerpark                            </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within a day      </td><td>1   </td><td> 58</td><td> 95</td><td> 9</td><td> 9</td><td>10</td><td>10</td><td> 9</td><td>10</td></tr>
	<tr><td>59484</td><td>Alex              </td><td>2009</td><td>12/2 </td><td>12/2/09 </td><td>7.62</td><td>  20168</td><td>Centrum-Oost                          </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within an hour    </td><td>1   </td><td> 25</td><td> 83</td><td> 9</td><td> 9</td><td> 9</td><td> 8</td><td>10</td><td> 9</td></tr>
	<tr><td>59484</td><td>Alex              </td><td>2009</td><td>12/2 </td><td>12/2/09 </td><td>7.62</td><td>3903880</td><td>Centrum-Oost                          </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within an hour    </td><td>1   </td><td> 14</td><td> 86</td><td> 9</td><td> 9</td><td> 9</td><td> 9</td><td>10</td><td> 9</td></tr>
	<tr><td>62341</td><td>Jurgen            </td><td>2009</td><td>12/11</td><td>12/11/09</td><td>7.59</td><td>1030014</td><td>Centrum-West                          </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within an hour    </td><td>1   </td><td> 13</td><td> 90</td><td> 9</td><td> 8</td><td>10</td><td>10</td><td>10</td><td> 9</td></tr>
	<tr><td>65041</td><td>Ym                </td><td>2009</td><td>12/22</td><td>12/22/09</td><td>7.56</td><td>  43980</td><td>Zuid                                  </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within a few hours</td><td>0.99</td><td> 46</td><td> 77</td><td> 7</td><td> 7</td><td> 9</td><td> 9</td><td> 9</td><td> 8</td></tr>
	<tr><td>65041</td><td>Ym                </td><td>2009</td><td>12/22</td><td>12/22/09</td><td>7.56</td><td>  85767</td><td>Centrum-West                          </td><td>Amsterdam</td><td>Amsterdam</td><td>⋯</td><td>within a few hours</td><td>0.99</td><td> 49</td><td> 73</td><td> 7</td><td> 7</td><td> 8</td><td> 9</td><td> 9</td><td> 7</td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋱</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>30445609</td><td>Eddy      </td><td>2015</td><td>4/1</td><td>4/1/15</td><td>2.28</td><td>5863372</td><td>Centrum-West                          </td><td>Amsterdam          </td><td>Amsterdam</td><td>⋯</td><td>N/A</td><td>N/A</td><td> 0</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>30454092</td><td>Irma      </td><td>2015</td><td>4/2</td><td>4/2/15</td><td>2.28</td><td>5864708</td><td>De Baarsjes - Oud-West                </td><td>Amsterdam          </td><td>Amsterdam</td><td>⋯</td><td>N/A</td><td>N/A</td><td> 0</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>30481836</td><td>Nathan    </td><td>2015</td><td>4/2</td><td>4/2/15</td><td>2.28</td><td>5870563</td><td>Centrum-West                          </td><td>Amsterdam          </td><td>Amsterdam</td><td>⋯</td><td>N/A</td><td>N/A</td><td> 0</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>30486130</td><td>Djo       </td><td>2015</td><td>4/2</td><td>4/2/15</td><td>2.28</td><td>5871369</td><td>Centrum-West                          </td><td>Amsterdam          </td><td>Amsterdam</td><td>⋯</td><td>N/A</td><td>N/A</td><td> 0</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>30521998</td><td>Ludwig    </td><td>2015</td><td>4/3</td><td>4/3/15</td><td>2.28</td><td>5877715</td><td>Centrum-Oost                          </td><td>Amsterdam          </td><td>Amsterdam</td><td>⋯</td><td>N/A</td><td>N/A</td><td> 0</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>30531848</td><td>Samantha  </td><td>2015</td><td>4/3</td><td>4/3/15</td><td>2.28</td><td>5879600</td><td>Osdorp                                </td><td>Amsterdam          </td><td>Amsterdam</td><td>⋯</td><td>N/A</td><td>N/A</td><td> 0</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>30534533</td><td>Anouk     </td><td>2015</td><td>4/3</td><td>4/3/15</td><td>2.28</td><td>5879968</td><td>Centrum-Oost                          </td><td>Amsterdam          </td><td>Amsterdam</td><td>⋯</td><td>N/A</td><td>N/A</td><td> 0</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>30571788</td><td>Wilma     </td><td>2015</td><td>4/4</td><td>4/4/15</td><td>2.28</td><td>5886594</td><td>Bijlmer-Oost                          </td><td>Amsterdam Zuid-Oost</td><td>Amsterdam</td><td>⋯</td><td>N/A</td><td>N/A</td><td> 0</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>30574000</td><td>Kathleen  </td><td>2015</td><td>4/4</td><td>4/4/15</td><td>2.28</td><td>5887073</td><td>Oostelijk Havengebied - Indische Buurt</td><td>Amsterdam          </td><td>Amsterdam</td><td>⋯</td><td>N/A</td><td>N/A</td><td> 0</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>30575462</td><td>James     </td><td>2015</td><td>4/4</td><td>4/4/15</td><td>2.28</td><td>5887362</td><td>Centrum-West                          </td><td>Amsterdam          </td><td>Amsterdam</td><td>⋯</td><td>N/A</td><td>N/A</td><td> 0</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>30592860</td><td>Ruud      </td><td>2015</td><td>4/4</td><td>4/4/15</td><td>2.28</td><td>5896701</td><td>Centrum-Oost                          </td><td>Amsterdam          </td><td>Amsterdam</td><td>⋯</td><td>N/A</td><td>N/A</td><td> 0</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>30593666</td><td>Trevelbadi</td><td>2015</td><td>4/4</td><td>4/4/15</td><td>2.28</td><td>5891027</td><td>Noord-West                            </td><td>Amsterdam          </td><td>Amsterdam</td><td>⋯</td><td>N/A</td><td>N/A</td><td> 0</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>30595041</td><td>Christiaan</td><td>2015</td><td>4/4</td><td>4/4/15</td><td>2.28</td><td>5891278</td><td>De Pijp - Rivierenbuurt               </td><td>Amsterdam          </td><td>Amsterdam</td><td>⋯</td><td>N/A</td><td>N/A</td><td> 0</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>      NA</td><td>NA        </td><td>  NA</td><td>NA </td><td>NA    </td><td>  NA</td><td>     NA</td><td>NA                                    </td><td>NA                 </td><td>NA       </td><td>⋯</td><td>NA </td><td>NA </td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>      NA</td><td>NA        </td><td>  NA</td><td>NA </td><td>NA    </td><td>  NA</td><td>     NA</td><td>NA                                    </td><td>NA                 </td><td>NA       </td><td>⋯</td><td>NA </td><td>NA </td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>      NA</td><td>NA        </td><td>  NA</td><td>NA </td><td>NA    </td><td>  NA</td><td>     NA</td><td>NA                                    </td><td>NA                 </td><td>NA       </td><td>⋯</td><td>NA </td><td>NA </td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>      NA</td><td>NA        </td><td>  NA</td><td>NA </td><td>NA    </td><td>  NA</td><td>     NA</td><td>NA                                    </td><td>NA                 </td><td>NA       </td><td>⋯</td><td>NA </td><td>NA </td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>      NA</td><td>NA        </td><td>  NA</td><td>NA </td><td>NA    </td><td>  NA</td><td>     NA</td><td>NA                                    </td><td>NA                 </td><td>NA       </td><td>⋯</td><td>NA </td><td>NA </td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>      NA</td><td>NA        </td><td>  NA</td><td>NA </td><td>NA    </td><td>  NA</td><td>     NA</td><td>NA                                    </td><td>NA                 </td><td>NA       </td><td>⋯</td><td>NA </td><td>NA </td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>      NA</td><td>NA        </td><td>  NA</td><td>NA </td><td>NA    </td><td>  NA</td><td>     NA</td><td>NA                                    </td><td>NA                 </td><td>NA       </td><td>⋯</td><td>NA </td><td>NA </td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>      NA</td><td>NA        </td><td>  NA</td><td>NA </td><td>NA    </td><td>  NA</td><td>     NA</td><td>NA                                    </td><td>NA                 </td><td>NA       </td><td>⋯</td><td>NA </td><td>NA </td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>      NA</td><td>NA        </td><td>  NA</td><td>NA </td><td>NA    </td><td>  NA</td><td>     NA</td><td>NA                                    </td><td>NA                 </td><td>NA       </td><td>⋯</td><td>NA </td><td>NA </td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>      NA</td><td>NA        </td><td>  NA</td><td>NA </td><td>NA    </td><td>  NA</td><td>     NA</td><td>NA                                    </td><td>NA                 </td><td>NA       </td><td>⋯</td><td>NA </td><td>NA </td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>      NA</td><td>NA        </td><td>  NA</td><td>NA </td><td>NA    </td><td>  NA</td><td>     NA</td><td>NA                                    </td><td>NA                 </td><td>NA       </td><td>⋯</td><td>NA </td><td>NA </td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>      NA</td><td>NA        </td><td>  NA</td><td>NA </td><td>NA    </td><td>  NA</td><td>     NA</td><td>NA                                    </td><td>NA                 </td><td>NA       </td><td>⋯</td><td>NA </td><td>NA </td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>      NA</td><td>NA        </td><td>  NA</td><td>NA </td><td>NA    </td><td>  NA</td><td>     NA</td><td>NA                                    </td><td>NA                 </td><td>NA       </td><td>⋯</td><td>NA </td><td>NA </td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>      NA</td><td>NA        </td><td>  NA</td><td>NA </td><td>NA    </td><td>  NA</td><td>     NA</td><td>NA                                    </td><td>NA                 </td><td>NA       </td><td>⋯</td><td>NA </td><td>NA </td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>      NA</td><td>NA        </td><td>  NA</td><td>NA </td><td>NA    </td><td>  NA</td><td>     NA</td><td>NA                                    </td><td>NA                 </td><td>NA       </td><td>⋯</td><td>NA </td><td>NA </td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>      NA</td><td>NA        </td><td>  NA</td><td>NA </td><td>NA    </td><td>  NA</td><td>     NA</td><td>NA                                    </td><td>NA                 </td><td>NA       </td><td>⋯</td><td>NA </td><td>NA </td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
	<tr><td>      NA</td><td>NA        </td><td>  NA</td><td>NA </td><td>NA    </td><td>  NA</td><td>     NA</td><td>NA                                    </td><td>NA                 </td><td>NA       </td><td>⋯</td><td>NA </td><td>NA </td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td></tr>
</tbody>
</table>




```R
colnames(airbnb_data)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'host_id'</li><li>'host_name'</li><li>'host_since_year'</li><li>'host_since_anniversary'</li><li>'Customer.Since'</li><li>'Age.in.years'</li><li>'id'</li><li>'neighbourhood_cleansed'</li><li>'city'</li><li>'city_translated'</li><li>'state'</li><li>'state_translated'</li><li>'zipcode'</li><li>'country'</li><li>'latitude'</li><li>'longitude'</li><li>'property_type'</li><li>'room_type'</li><li>'accommodates'</li><li>'bathrooms'</li><li>'bedrooms'</li><li>'beds'</li><li>'bed_type'</li><li>'price'</li><li>'guests_included'</li><li>'extra_people'</li><li>'minimum_nights'</li><li>'customers...50..review.rate'</li><li>'X.Daily.Rev.per.2.guests..unless.limited.to.1.'</li><li>'Min.Nights'</li><li>'Total.Rev'</li><li>'host_response_time'</li><li>'host_response_rate'</li><li>'number_of_reviews'</li><li>'review_scores_rating'</li><li>'review_scores_accuracy'</li><li>'review_scores_cleanliness'</li><li>'review_scores_checkin'</li><li>'review_scores_communication'</li><li>'review_scores_location'</li><li>'review_scores_value'</li></ol>



## Clean Data

#### Get corresponding response and predictor columns


```R
# need to replace categorical data with indicator functions
# property_apmt = 1 if "Apartment", else = 0
# property_house = 1 if "House", else = 0
# property_boat = 1 if "Boat", else = 0
# if property_apmt, property_house, and property_boat are 0, then property is "Bed & Breakfast"
airbnb_data$property_apmt <- ifelse(airbnb_data$property_type=="Apartment", "1", "0")
airbnb_data$property_house <- ifelse(airbnb_data$property_type=="House", "1", "0")
airbnb_data$property_boat <- ifelse(airbnb_data$property_type=="Boat", "1", "0")
airbnb_data$delete <- ifelse(airbnb_data$property_type=="Apartment"|airbnb_data$property_type=="House"|
                             airbnb_data$property_type=="Boat"|airbnb_data$property_type=="Bed & Breakfast", "0", NA)

# room_entire = 1 if "Entire home/apt", else = 0
# room_private = 1 if "Private room", else = 0
# if both room_entire and room_private are 0, then room is "Shared room"
airbnb_data$room_entire <- ifelse(airbnb_data$room_type == "Entire home/apt", "1", "0")
airbnb_data$room_private <- ifelse(airbnb_data$room_type == "Private room", "1", "0")
```


```R
new_data <- subset(as.data.frame(airbnb_data), 
                   select = c(price, review_scores_rating, minimum_nights, property_apmt, 
                              property_house, property_boat, delete, room_private, room_entire, accommodates))
```


```R
head(new_data)
dim(new_data)
```


<table class="dataframe">
<caption>A data.frame: 6 × 10</caption>
<thead>
	<tr><th></th><th scope=col>price</th><th scope=col>review_scores_rating</th><th scope=col>minimum_nights</th><th scope=col>property_apmt</th><th scope=col>property_house</th><th scope=col>property_boat</th><th scope=col>delete</th><th scope=col>room_private</th><th scope=col>room_entire</th><th scope=col>accommodates</th></tr>
	<tr><th></th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td> $130 </td><td> 98</td><td>4</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>4</td></tr>
	<tr><th scope=row>2</th><td> $59  </td><td> 97</td><td>3</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>3</th><td> $95  </td><td> 92</td><td>3</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>4</td></tr>
	<tr><th scope=row>4</th><td> $100 </td><td> 97</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>2</td></tr>
	<tr><th scope=row>5</th><td> $250 </td><td>100</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>6</td></tr>
	<tr><th scope=row>6</th><td> $140 </td><td> NA</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>4</td></tr>
</tbody>
</table>




<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>7833</li><li>10</li></ol>



#### Remove rows that contains NA


```R
# Remove rows with NA values
clean_data <- na.omit(new_data)
```


```R
head(clean_data)
dim(clean_data)
```


<table class="dataframe">
<caption>A data.frame: 6 × 10</caption>
<thead>
	<tr><th></th><th scope=col>price</th><th scope=col>review_scores_rating</th><th scope=col>minimum_nights</th><th scope=col>property_apmt</th><th scope=col>property_house</th><th scope=col>property_boat</th><th scope=col>delete</th><th scope=col>room_private</th><th scope=col>room_entire</th><th scope=col>accommodates</th></tr>
	<tr><th></th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td> $130 </td><td> 98</td><td>4</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>4</td></tr>
	<tr><th scope=row>2</th><td> $59  </td><td> 97</td><td>3</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>3</th><td> $95  </td><td> 92</td><td>3</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>4</td></tr>
	<tr><th scope=row>4</th><td> $100 </td><td> 97</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>2</td></tr>
	<tr><th scope=row>5</th><td> $250 </td><td>100</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>6</td></tr>
	<tr><th scope=row>7</th><td> $115 </td><td> 95</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
</tbody>
</table>




<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>6016</li><li>10</li></ol>



#### Check if there are still any empty entries


```R
has_empty_entries <- sum(is.na(clean_data)) > 0
has_empty_entries
```


FALSE


#### Remove duplicates


```R
unique(clean_data)
```


<table class="dataframe">
<caption>A data.frame: 4567 × 10</caption>
<thead>
	<tr><th></th><th scope=col>price</th><th scope=col>review_scores_rating</th><th scope=col>minimum_nights</th><th scope=col>property_apmt</th><th scope=col>property_house</th><th scope=col>property_boat</th><th scope=col>delete</th><th scope=col>room_private</th><th scope=col>room_entire</th><th scope=col>accommodates</th></tr>
	<tr><th></th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td> $130 </td><td> 98</td><td>4</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>4</td></tr>
	<tr><th scope=row>2</th><td> $59  </td><td> 97</td><td>3</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>3</th><td> $95  </td><td> 92</td><td>3</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>4</td></tr>
	<tr><th scope=row>4</th><td> $100 </td><td> 97</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>2</td></tr>
	<tr><th scope=row>5</th><td> $250 </td><td>100</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>6</td></tr>
	<tr><th scope=row>7</th><td> $115 </td><td> 95</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>8</th><td> $80  </td><td> 95</td><td>3</td><td>0</td><td>1</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>9</th><td> $80  </td><td> 96</td><td>6</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>3</td></tr>
	<tr><th scope=row>10</th><td> $90  </td><td> 93</td><td>3</td><td>0</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>2</td></tr>
	<tr><th scope=row>11</th><td> $100 </td><td> 95</td><td>7</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>3</td></tr>
	<tr><th scope=row>12</th><td> $95  </td><td>100</td><td>3</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>3</td></tr>
	<tr><th scope=row>13</th><td> $145 </td><td> 99</td><td>3</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>2</td></tr>
	<tr><th scope=row>14</th><td> $132 </td><td> 99</td><td>4</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>3</td></tr>
	<tr><th scope=row>15</th><td> $79  </td><td>100</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>2</td></tr>
	<tr><th scope=row>16</th><td> $180 </td><td> 99</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>4</td></tr>
	<tr><th scope=row>18</th><td> $82  </td><td> 98</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>19</th><td> $59  </td><td> 95</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>24</th><td> $35  </td><td> 99</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>4</td></tr>
	<tr><th scope=row>25</th><td> $43  </td><td> 95</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>4</td></tr>
	<tr><th scope=row>26</th><td> $50  </td><td> 83</td><td>1</td><td>0</td><td>1</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>27</th><td> $50  </td><td> 86</td><td>1</td><td>0</td><td>1</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>28</th><td> $69  </td><td> 90</td><td>3</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>2</td></tr>
	<tr><th scope=row>29</th><td> $80  </td><td> 77</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>4</td></tr>
	<tr><th scope=row>30</th><td> $80  </td><td> 73</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>4</td></tr>
	<tr><th scope=row>33</th><td> $110 </td><td> 88</td><td>3</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>4</td></tr>
	<tr><th scope=row>34</th><td> $74  </td><td> 97</td><td>4</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>35</th><td> $250 </td><td> 96</td><td>3</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>8</td></tr>
	<tr><th scope=row>36</th><td> $200 </td><td> 90</td><td>3</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>6</td></tr>
	<tr><th scope=row>37</th><td> $180 </td><td> 94</td><td>3</td><td>0</td><td>0</td><td>1</td><td>0</td><td>0</td><td>1</td><td>6</td></tr>
	<tr><th scope=row>38</th><td> $200 </td><td> 95</td><td>3</td><td>0</td><td>0</td><td>1</td><td>0</td><td>0</td><td>1</td><td>6</td></tr>
	<tr><th scope=row>⋮</th><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><th scope=row>7552</th><td> $100 </td><td>100</td><td>2</td><td>0</td><td>0</td><td>1</td><td>0</td><td>0</td><td>1</td><td>2</td></tr>
	<tr><th scope=row>7553</th><td> $70  </td><td>100</td><td>1</td><td>0</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>7</td></tr>
	<tr><th scope=row>7561</th><td> $75  </td><td> 80</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>7563</th><td> $82  </td><td> 90</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>7565</th><td> $85  </td><td> 80</td><td>3</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>4</td></tr>
	<tr><th scope=row>7569</th><td> $125 </td><td>100</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>4</td></tr>
	<tr><th scope=row>7584</th><td> $96  </td><td> 93</td><td>2</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>7592</th><td> $150 </td><td> 87</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>3</td></tr>
	<tr><th scope=row>7593</th><td> $90  </td><td> 88</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>3</td></tr>
	<tr><th scope=row>7595</th><td> $124 </td><td>100</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>4</td></tr>
	<tr><th scope=row>7609</th><td> $55  </td><td>100</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>4</td></tr>
	<tr><th scope=row>7613</th><td> $89  </td><td>100</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>7617</th><td> $65  </td><td>100</td><td>1</td><td>0</td><td>1</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>7620</th><td> $93  </td><td> 80</td><td>3</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>7625</th><td> $100 </td><td>100</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>7653</th><td> $68  </td><td>100</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>4</td></tr>
	<tr><th scope=row>7655</th><td> $66  </td><td> 60</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>3</td></tr>
	<tr><th scope=row>7656</th><td> $39  </td><td> 90</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>7660</th><td> $90  </td><td> 60</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>3</td></tr>
	<tr><th scope=row>7662</th><td> $95  </td><td>100</td><td>2</td><td>0</td><td>1</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>7674</th><td> $135 </td><td>100</td><td>1</td><td>0</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>5</td></tr>
	<tr><th scope=row>7697</th><td> $59  </td><td> 93</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>2</td></tr>
	<tr><th scope=row>7701</th><td> $95  </td><td> 80</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>4</td></tr>
	<tr><th scope=row>7707</th><td> $59  </td><td> 80</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>7712</th><td> $300 </td><td>100</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>7</td></tr>
	<tr><th scope=row>7720</th><td> $60  </td><td>100</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>7737</th><td> $69  </td><td>100</td><td>4</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>7754</th><td> $69  </td><td>100</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>2</td></tr>
	<tr><th scope=row>7767</th><td> $59  </td><td> 87</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>7772</th><td> $93  </td><td>100</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
</tbody>
</table>




```R
install.packages("dplyr")

library(dplyr)
```

    Installing package into ‘/opt/r’
    (as ‘lib’ is unspecified)
    



```R
new_clean_data <- subset(clean_data %>% distinct(), # remove duplicate rows and only keep the distinct rows
                         select=c(price, review_scores_rating, minimum_nights, property_apmt, 
                              property_house, property_boat, room_private, room_entire, accommodates))
dim(new_clean_data)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>4567</li><li>9</li></ol>



#### Get data summary


```R
summary(new_clean_data)
```


        price           review_scores_rating minimum_nights   property_apmt     
     Length:4567        Min.   : 20.00       Min.   : 1.000   Length:4567       
     Class :character   1st Qu.: 90.00       1st Qu.: 2.000   Class :character  
     Mode  :character   Median : 94.00       Median : 2.000   Mode  :character  
                        Mean   : 92.53       Mean   : 2.574                     
                        3rd Qu.: 98.00       3rd Qu.: 3.000                     
                        Max.   :100.00       Max.   :27.000                     
     property_house     property_boat      room_private       room_entire       
     Length:4567        Length:4567        Length:4567        Length:4567       
     Class :character   Class :character   Class :character   Class :character  
     Mode  :character   Mode  :character   Mode  :character   Mode  :character  
                                                                                
                                                                                
                                                                                
      accommodates   
     Min.   : 1.000  
     1st Qu.: 2.000  
     Median : 3.000  
     Mean   : 3.286  
     3rd Qu.: 4.000  
     Max.   :16.000  


#### Convert random variables to appropriate data types


```R
columns_to_convert <- c("price", "room_entire", "room_private", "property_apmt", "property_house", "property_boat")

for (col_name in columns_to_convert) {
  new_clean_data[, col_name] <- as.numeric(gsub("[^0-9.]", "", new_clean_data[, col_name]))
}
```


```R
# check summary again after conversion
summary(new_clean_data)
attach(new_clean_data)
```


         price        review_scores_rating minimum_nights   property_apmt   
     Min.   :  19.0   Min.   : 20.00       Min.   : 1.000   Min.   :0.0000  
     1st Qu.:  80.0   1st Qu.: 90.00       1st Qu.: 2.000   1st Qu.:1.0000  
     Median : 109.0   Median : 94.00       Median : 2.000   Median :1.0000  
     Mean   : 128.1   Mean   : 92.53       Mean   : 2.574   Mean   :0.7793  
     3rd Qu.: 150.0   3rd Qu.: 98.00       3rd Qu.: 3.000   3rd Qu.:1.0000  
     Max.   :1400.0   Max.   :100.00       Max.   :27.000   Max.   :1.0000  
     property_house   property_boat      room_private     room_entire    
     Min.   :0.0000   Min.   :0.00000   Min.   :0.0000   Min.   :0.0000  
     1st Qu.:0.0000   1st Qu.:0.00000   1st Qu.:0.0000   1st Qu.:1.0000  
     Median :0.0000   Median :0.00000   Median :0.0000   Median :1.0000  
     Mean   :0.1062   Mean   :0.05737   Mean   :0.2106   Mean   :0.7826  
     3rd Qu.:0.0000   3rd Qu.:0.00000   3rd Qu.:0.0000   3rd Qu.:1.0000  
     Max.   :1.0000   Max.   :1.00000   Max.   :1.0000   Max.   :1.0000  
      accommodates   
     Min.   : 1.000  
     1st Qu.: 2.000  
     Median : 3.000  
     Mean   : 3.286  
     3rd Qu.: 4.000  
     Max.   :16.000  


### Fit Model (Preliminary)

#### Model 


```R
model1 <- lm(price ~ review_scores_rating + minimum_nights + property_apmt + property_house + property_boat
             + room_entire + room_private + accommodates)
summary(model1)
e_hat <- resid(model1)
y_hat <- fitted(model1)
```


    
    Call:
    lm(formula = price ~ review_scores_rating + minimum_nights + 
        property_apmt + property_house + property_boat + room_entire + 
        room_private + accommodates)
    
    Residuals:
        Min      1Q  Median      3Q     Max 
    -385.29  -31.73   -7.06   22.44  968.99 
    
    Coefficients:
                         Estimate Std. Error t value Pr(>|t|)    
    (Intercept)          -56.3551    15.5290  -3.629 0.000288 ***
    review_scores_rating   0.6280     0.1141   5.503 3.93e-08 ***
    minimum_nights         0.3617     0.4894   0.739 0.459884    
    property_apmt        -15.1401     4.1651  -3.635 0.000281 ***
    property_house         3.9029     4.8252   0.809 0.418639    
    property_boat         -0.3190     5.5895  -0.057 0.954485    
    room_entire           73.4484    10.9492   6.708 2.21e-11 ***
    room_private          30.6132    11.0821   2.762 0.005761 ** 
    accommodates          22.1746     0.5176  42.837  < 2e-16 ***
    ---
    Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
    
    Residual standard error: 60.5 on 4558 degrees of freedom
    Multiple R-squared:  0.417,	Adjusted R-squared:  0.416 
    F-statistic: 407.6 on 8 and 4558 DF,  p-value: < 2.2e-16



#### Checking MLR assumptions


```R
# 1. Conditional mean response
plot(y_hat ~ price, main="Price vs. Fitted Value", ylab="Fitted Value", xlab="Price")
abline(a=0, b=1, lty=2)
```


    
![png](output_27_0.png)
    


Observations: Points are along the diagonal, with scatter. However, it can be seen that there is fanning, so there is possibly a violation of constant variance. There is also clustering of points near the lower left of the plot.


```R
# 2. Conditional mean predictors
pairs(new_clean_data)
```


    
![png](output_29_0.png)
    


Observations: Points are either in lines (which is good), or in weird clusters. Transformations may be good.

#### Residual Plots


```R
# Checking for normality
qqnorm(e_hat)
qqline(e_hat)
```


    
![png](output_32_0.png)
    


Observations: Normality seems to be relatively good, although there is still room for improvement.


```R
# Residual vs. fitted
plot(e_hat, y_hat, main="Residuals vs Fitted", ylab="Residuals", xlab="Fitted")
```


    
![png](output_34_0.png)
    


Observations: There is a cluster in the plot and a fanning pattern, suggesting violation of constant variance. However, this does not indicate whether there are actual violations, because this is a multiple variable linear regression.


```R
# Scatterplots
# Residual vs. Review ratings
plot(x=review_scores_rating, y=e_hat, main="Residual vs. Review ratings", ylab="Residuals", xlab="Review ratings")

# Residual vs. Minimum nights
plot(x=minimum_nights, y=e_hat, main="Residual vs. Minimum nights", ylab="Residuals", xlab="Minimum nights")

# Residual vs. Accommodates
plot(x=accommodates, y=e_hat, main="Residual vs. Accommodates", ylab="Residuals", xlab="Accommodates")

# Boxplots
# Residual vs. Property apartment
boxplot(e_hat ~ property_apmt , main="Residual vs. Property apartment", ylab="Residuals", xlab="Property apartment")

# Residual vs. Property house
boxplot(e_hat ~ property_house, main="Residual vs. Property house", ylab="Residual", xlab="Property house")

# Residual vs. Property boat
boxplot(e_hat ~ property_boat, main="Residual vs. Property boat", ylab="Residual", xlab="Property boat")

# Residual vs. Room private
boxplot(e_hat ~ room_private, main="Residual vs. Room private", ylab="Residuals", xlab="Room private")

# Residual vs. Room entire
boxplot(e_hat ~ room_entire, main="Residual vs. Room entire", ylab="Residuals", xlab="Room entire")
```


    
![png](output_36_0.png)
    



    
![png](output_36_1.png)
    



    
![png](output_36_2.png)
    



    
![png](output_36_3.png)
    



    
![png](output_36_4.png)
    



    
![png](output_36_5.png)
    



    
![png](output_36_6.png)
    



    
![png](output_36_7.png)
    


Observations: There seems to be a cluster and fanning pattern for the plots for the continuous predictor variables. These all suggests violation of constant variance. However, this does not indicate whether there are actual violations, because this is a multiple variable linear regression.

#### Histogram of the price data to check for skew


```R
hist(new_clean_data$price, main="Histogram", xlab="price")
```


    
![png](output_39_0.png)
    


From the histogram above, the response is a right skewed, convert it to normal.

#### Convert the data so that it has a normal price distribution.


```R
install.packages("MASS")
library(MASS)
```

    Installing package into ‘/opt/r’
    (as ‘lib’ is unspecified)
    
    
    Attaching package: ‘MASS’
    
    
    The following object is masked from ‘package:dplyr’:
    
        select
    
    



```R
boxcox(lm(new_clean_data$price~1))
```


    
![png](output_43_0.png)
    



```R
newprice <- log(new_clean_data$price)
hist(newprice, main="Histogram", xlab="price")
```


    
![png](output_44_0.png)
    



```R
data <- data.frame(cbind(newprice, new_clean_data[,-1]))
```


```R
head(data)
dim(data)
```


<table class="dataframe">
<caption>A data.frame: 6 × 9</caption>
<thead>
	<tr><th></th><th scope=col>newprice</th><th scope=col>review_scores_rating</th><th scope=col>minimum_nights</th><th scope=col>property_apmt</th><th scope=col>property_house</th><th scope=col>property_boat</th><th scope=col>room_private</th><th scope=col>room_entire</th><th scope=col>accommodates</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>4.867534</td><td> 98</td><td>4</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>4</td></tr>
	<tr><th scope=row>2</th><td>4.077537</td><td> 97</td><td>3</td><td>1</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
	<tr><th scope=row>3</th><td>4.553877</td><td> 92</td><td>3</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>4</td></tr>
	<tr><th scope=row>4</th><td>4.605170</td><td> 97</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>2</td></tr>
	<tr><th scope=row>5</th><td>5.521461</td><td>100</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>6</td></tr>
	<tr><th scope=row>6</th><td>4.744932</td><td> 95</td><td>1</td><td>1</td><td>0</td><td>0</td><td>1</td><td>0</td><td>2</td></tr>
</tbody>
</table>




<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>4567</li><li>9</li></ol>




```R
summary(data)
```


        newprice     review_scores_rating minimum_nights   property_apmt   
     Min.   :2.944   Min.   : 20.00       Min.   : 1.000   Min.   :0.0000  
     1st Qu.:4.382   1st Qu.: 90.00       1st Qu.: 2.000   1st Qu.:1.0000  
     Median :4.691   Median : 94.00       Median : 2.000   Median :1.0000  
     Mean   :4.712   Mean   : 92.53       Mean   : 2.574   Mean   :0.7793  
     3rd Qu.:5.011   3rd Qu.: 98.00       3rd Qu.: 3.000   3rd Qu.:1.0000  
     Max.   :7.244   Max.   :100.00       Max.   :27.000   Max.   :1.0000  
     property_house   property_boat      room_private     room_entire    
     Min.   :0.0000   Min.   :0.00000   Min.   :0.0000   Min.   :0.0000  
     1st Qu.:0.0000   1st Qu.:0.00000   1st Qu.:0.0000   1st Qu.:1.0000  
     Median :0.0000   Median :0.00000   Median :0.0000   Median :1.0000  
     Mean   :0.1062   Mean   :0.05737   Mean   :0.2106   Mean   :0.7826  
     3rd Qu.:0.0000   3rd Qu.:0.00000   3rd Qu.:0.0000   3rd Qu.:1.0000  
     Max.   :1.0000   Max.   :1.00000   Max.   :1.0000   Max.   :1.0000  
      accommodates   
     Min.   : 1.000  
     1st Qu.: 2.000  
     Median : 3.000  
     Mean   : 3.286  
     3rd Qu.: 4.000  
     Max.   :16.000  


### Fit Model (After Boxcox Transformation)


```R
attach(data)
```

    The following object is masked _by_ .GlobalEnv:
    
        newprice
    
    
    The following objects are masked from new_clean_data:
    
        accommodates, minimum_nights, property_apmt, property_boat,
        property_house, review_scores_rating, room_entire, room_private
    
    



```R
model2 <- lm(newprice ~ review_scores_rating + minimum_nights + property_apmt + property_house + property_boat
             + room_entire + room_private + accommodates)
summary(model2)

e_hat2 <- resid(model2)
y_hat2 <- fitted(model2)
```


    
    Call:
    lm(formula = newprice ~ review_scores_rating + minimum_nights + 
        property_apmt + property_house + property_boat + room_entire + 
        room_private + accommodates)
    
    Residuals:
         Min       1Q   Median       3Q      Max 
    -2.68087 -0.25477 -0.00699  0.24469  1.41770 
    
    Coefficients:
                           Estimate Std. Error t value Pr(>|t|)    
    (Intercept)           3.2395208  0.0988983  32.756  < 2e-16 ***
    review_scores_rating  0.0054924  0.0007267   7.558 4.92e-14 ***
    minimum_nights       -0.0067670  0.0031168  -2.171    0.030 *  
    property_apmt        -0.1680818  0.0265256  -6.337 2.58e-10 ***
    property_house       -0.0443946  0.0307298  -1.445    0.149    
    property_boat        -0.0539293  0.0355970  -1.515    0.130    
    room_entire           0.8739455  0.0697311  12.533  < 2e-16 ***
    room_private          0.3574052  0.0705773   5.064 4.27e-07 ***
    accommodates          0.1100338  0.0032967  33.377  < 2e-16 ***
    ---
    Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
    
    Residual standard error: 0.3853 on 4558 degrees of freedom
    Multiple R-squared:  0.4442,	Adjusted R-squared:  0.4432 
    F-statistic: 455.4 on 8 and 4558 DF,  p-value: < 2.2e-16



#### Checking MLR Assumptions


```R
# 1. Conditional mean response
plot(y_hat ~ newprice, main="Price vs. Fitted Value", ylab="Fitted Value", xlab="Price")
abline(a=0, b=1, lty=2)
```


    
![png](output_52_0.png)
    



```R
# 2. Conditional mean predictors
pairs(data)
```


    
![png](output_53_0.png)
    


#### Residual Plots


```R
qqnorm(e_hat2)
qqline(e_hat2)
```


    
![png](output_55_0.png)
    


Observations: The normality plot seems much better than before the boxcox transformation


```R
# Residual vs. fitted
plot(e_hat2, y_hat2, main="Residuals vs Fitted", ylab="Residuals", xlab="Fitted")
```


    
![png](output_57_0.png)
    


Observations: The fanning pattern seems to have been dealt with. However, now there seems to be some clustering.


```R
# Scatterplots
# Residual vs. Review ratings
plot(x=review_scores_rating, y=e_hat2, main="Residual vs. Review ratings", ylab="Residuals", xlab="Review ratings")

# Residual vs. Minimum nights
plot(x=minimum_nights, y=e_hat2, main="Residual vs. Minimum nights", ylab="Residuals", xlab="Minimum nights")

# Residual vs. Accommodates
plot(x=accommodates, y=e_hat2, main="Residual vs. Accommodates", ylab="Residuals", xlab="Accommodates")

# Boxplots
# Residual vs. Property apartment
boxplot(e_hat2 ~ property_apmt , main="Residual vs. Property apartment", ylab="Residuals", xlab="Property apartment")

# Residual vs. Property house
boxplot(e_hat2 ~ property_house, main="Residual vs. Property house", ylab="Residual", xlab="Property house")

# Residual vs. Property boat
boxplot(e_hat2 ~ property_boat , main="Residual vs. Property boat", ylab="Residuals", xlab="Property boat")

# Residual vs. Room entire
boxplot(e_hat2 ~ room_entire, main="Residual vs. Room entire", ylab="Residuals", xlab="Room entire")

# Residual vs. Room private
boxplot(e_hat2 ~ room_type, main="Residual vs. Room private", ylab="Residuals", xlab="Room private")
```


    
![png](output_59_0.png)
    



    
![png](output_59_1.png)
    



    
![png](output_59_2.png)
    



    
![png](output_59_3.png)
    



    
![png](output_59_4.png)
    



    
![png](output_59_5.png)
    



    Error in eval(predvars, data, env): object 'room_type' not found
    Traceback:


    1. boxplot(e_hat2 ~ room_type, main = "Residual vs. Room private", 
     .     ylab = "Residuals", xlab = "Room private")

    2. boxplot.formula(e_hat2 ~ room_type, main = "Residual vs. Room private", 
     .     ylab = "Residuals", xlab = "Room private")

    3. eval(m, parent.frame())

    4. eval(m, parent.frame())

    5. stats::model.frame.default(formula = e_hat2 ~ room_type)

    6. eval(predvars, data, env)

    7. eval(predvars, data, env)



    
![png](output_59_7.png)
    


Observations: The fanning pattern from before seems to be much better. However there is still a clustering of points.
